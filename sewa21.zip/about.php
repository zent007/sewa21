<?php
include 'koneksi.php';
include 'fungsi.php';
include 'index.php';
?>

    <!-- Morris Charts CSS -->
    <link href="vendor/morrisjs/morris.css" rel="stylesheet">

<div align="center">
	<h1>ABOUT
	<h4><a href="sewa21.php"><span class="glyphicon-home"></span>SEWA21</a></h4>   
    <h6>Penyewaan Kaset</h6>
</div>
    <div id="wrapper">
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Update Terbaru
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <p>fitur dari Wishlist Feature yang sudah cek bila namun belum berfungsi
                             maka file/syntax/function/dll masih ada di tes*.php </p>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Wishlist Feature
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <li>pagination page <span class="glyphicon-ok"></span>almost</li>
                            <li>search <span class="glyphicon-ok"></span></li>
                            <li>sipnosis dipersingkat dengan read more<span class="glyphicon-ok"></span></li>
                            <li>thumbnail image for blank image</li>
                            <li>kategori kaset</li>
                            <li>kaset-profile.php use function primary link like WP</li>
                            <li>transaksi lebih dari satu</li>
                            <li>transaksi libur/tanpa pemasukan = per tgl diberi nilai 0 atau koson(dilewati) ?</li>
                            <li>sewa menu integrated with ajax<span class="glyphicon-ok"></span>good but not perfect</li>
                            <li>upgrade editor for sipnosis <span class="glyphicon-ok"></span></li>
                            <li>not found page</li>
                            <li>laporan chart sort by week and month</li>
                            <li>logo SEWA21</li>
                            <li>optimize web design</li>
                            <li>upgrade security</li>
                            <ul>login with hash/md5</ul>
                            <ul>pencegahan input tidak boleh kosong</ul>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
                
                <!-- /.col-lg-6 -->
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Penggunaan Morris.js 
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <p>Morris.js is a jQuery based charting plugin created by Olly Smith. In SB Admin, we are using the most recent version of Morris.js which includes the resize function, which makes the charts fully responsive. The documentation for Morris.js is available on their website, <a target="_blank" href="http://morrisjs.github.io/morris.js/">http://morrisjs.github.io/morris.js/</a>.</p>
                            <a target="_blank" class="btn btn-default btn-lg btn-block" href="http://morrisjs.github.io/morris.js/">View Morris.js Documentation</a>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php include 'footer.php'; ?>