wishlist feature
- pagination
- chart menggunakan (morris.js , highchart.js)
- login with hash/md5
- log DB menggunakan CURRENT-TIMESTAP 
05/12/2016
- bug mengupload menggunakan skrip yang di panggil melalui function
- kaset-register.php bugged
- alternative kaset-register.php = fupload.php
- tambah keterangan log (kaset_log_date) untuk fupload.php dan kaset-regiater.php 
- 

06/12/2016
- log DB for kaset success