	<h6 align="center">SEWA21 Version 0.526.423</h6>
	<h6 align="center">created by <a href="about.php">zain</a> - <?php echo date("Y");?></h6>
	</div><!--div container-->
</body>
</html>

