<?php

//LAPORAN TRANSAKSI

function listALL($koneksi){
	$no =1;
	$sql = "SELECT transaksi.*,kaset.kaset_nama,kaset.kaset_harga FROM kaset RIGHT JOIN transaksi ON kaset.kaset_id=transaksi.kaset_id";
	$hasil = $koneksi->query($sql);
	while ($row = $hasil->fetch_assoc()) {
		echo '<tr>
				<td>'.$no++.'</td>
				<td>'.$row["transaksi_id"].'</td>
				<td>'.$row["kaset_id"].'</td>
				<td>'.$row["kaset_nama"].'</td>
				<td>'.$row["transaksi_tgl_sewa"].'</td>
				<td>'.$row["transaksi_tgl_kembali"].'</td>
				<td>'.$row["kaset_harga"].'</td>
			  </tr>';

	}
}

function transaksi_daftar($koneksi){
if (isset($_POST['daftar_transaksi'])){

$kaset_id = $_POST['kaset_id'];
$transaksi_tgl_sewa = $_POST['transaksi_tgl_sewa'];
$transaksi_tgl_kembali = $_POST['transaksi_tgl_kembali'];

$sql = "INSERT INTO transaksi (kaset_id, transaksi_tgl_sewa, transaksi_tgl_kembali) VALUES ('$kaset_id','$transaksi_tgl_sewa','$transaksi_tgl_kembali' )";
$hasil= $koneksi->query($sql);

	if (!$hasil) {
		die("koneksi gagal: ".mysqli_connect_error());
	}
	}
}

//KASET 
function kaset_daftar($koneksi){
if (isset($_POST['daftar_kaset'])){
	$image=$_FILES['kaset_gambar']['tmp_name'];
    $image= addslashes(file_get_contents($_FILES['kaset_gambar']['tmp_name']));
    $image_name= time()."".$_FILES['kaset_gambar']['name']; 
    $image_size=getimagesize($_FILES['kaset_gambar']['tmp_name']);
    if ($image_size == FALSE) {
      echo "NO IMG";
    } else {
    move_uploaded_file($_FILES["kaset_gambar"]["tmp_name"], "unggah/".$image_name);
    $gambar="unggah/".$image_name;
  }
$kaset_nama = $_POST['kaset_nama'];
$kaset_sipnosis = $_POST['kaset_sipnosis'];
$kaset_persediaan = $_POST['kaset_persediaan'];
$kaset_harga = $_POST['kaset_harga'];

		$sql = "INSERT INTO kaset (kaset_nama, kaset_sipnosis, kaset_persediaan, kaset_harga, gambar) VALUES ('$kaset_nama','$kaset_sipnosis','$kaset_persediaan','$kaset_harga','$gambar' )";
		$hasil= $koneksi->query($sql);
		
	}
}

function opsi_kaset($koneksi) {
	$sql = "SELECT kaset_id FROM kaset";
	$hasil = $koneksi->query($sql);
	while ($row = $hasil->fetch_assoc()) {
		echo '<option>'.$row["kaset_id"].'</option>';
	}
}





function kaset($koneksi){
	$no =1;
	$sql = "SELECT * FROM kaset";
	$hasil = $koneksi->query($sql);
	while ($row = $hasil->fetch_assoc()) {
		echo '<tr>
				<td>'.$no++.'</td>
				<td>'.$row["kaset_id"].'</td>
				<td>'.$row["kaset_nama"].'</td>
				<td>'.$row["kaset_sipnosis"].'</td>
				<td align="center">'.$row["kaset_persediaan"].'</td>
				<td>'.$row["kaset_harga"].'</td>
			  </tr>';

	}
}



function kaset_medit($koneksi){
if (isset($_POST['medit_kaset'])) {
$kaset_id = $_POST['kaset_id'];
$new_kaset_id = $_POST['new_kaset_id'];
$kaset_nama = $_POST['kaset_nama'];
$kaset_sipnosis = $_POST['kaset_sipnosis'];
$kaset_persediaan = $_POST['kaset_persediaan'];
$kaset_harga = $_POST['kaset_harga'];

$sql = "UPDATE kaset SET kaset_id='$new_kaset_id' , kaset_nama='$kaset_nama' , kaset_sipnosis='$kaset_sipnosis', kaset_persediaan='$kaset_persediaan', kaset_harga='$kaset_harga' WHERE kaset_id='$kaset_id' ";
$hasil= $koneksi->query($sql);
	
	}
}

function kaset_hapus($koneksi){
	if (isset($_POST['hapus_kaset'])){
		$kaset_id = $_POST['kaset_id'];

		$sql = "DELETE FROM kaset WHERE kaset_id='$kaset_id'";
		$hasil= $koneksi->query($sql);
		header("Location: kaset-edit.php");
	}
}

//member

function member_daftar($koneksi){
	if (isset($_POST['daftar_member'])) {
		$member_nama = $_POST['member_nama'];
		$member_alamat = $_POST['member_alamat'];
	$sql = "INSERT INTO member (member_nama, member_alamat) VALUES ('$member_nama','$member_alamat')";
	$hasil= $koneksi->query($sql);
	header("Location: member.php");
	}
}

function member($koneksi) {
	$no = 1;
	$sql = "SELECT * FROM member";
	$hasil = $koneksi->query($sql);
	while ($row = $hasil->fetch_assoc()) {
		echo '<tr>
				<td>'.$no++.'</td>
				<td>'.$row["member_id"].'</td>
				<td>'.$row["member_nama"].'</td>
				<td>'.$row["member_alamat"].'</td>
			  </tr>';

	}
}

function member_medit($koneksi){
if (isset($_POST['medit_member'])) {
$member_id = $_POST['member_id'];
$new_member_id = $_POST['new_member_id'];
$member_nama = $_POST['member_nama'];
$member_alamat = $_POST['member_alamat'];

$sql = "UPDATE member SET member_id='$new_member_id' , member_nama='$member_nama' , member_alamat='$member_alamat' WHERE member_id='$member_id' ";
$hasil= $koneksi->query($sql);
header("Location: member-edit.php");

	}
}

function member_hapus($koneksi){
	if (isset($_POST['hapus_member'])){
		$member_id = $_POST['member_id'];

		$sql = "DELETE FROM member WHERE member_id='$member_id'";
		$hasil= $koneksi->query($sql);
		header("Location: member-edit.php");
	}
}

// upload 
function tesUPLOAD($koneksi){

if(isset($_POST["daftar_kaset"])) {

	$target_dir = "unggah/";
	// target file = merename nama file dengan time() agar file tdk ada yang sama
	$target_file = $target_dir . time()."".$_FILES['fileToUpload']['tmp_name'];
	$uploadOk = 1;
	$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
	// Check if image file is a actual image or fake image
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    //file di upload ke dir unggah/ dengan nama file yang sudah di rename
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
        // insert keterangan source gambar yang diupload

        $kaset_nama = $_POST['kaset_nama'];
        $kaset_sipnosis = $_POST['kaset_sipnosis'];
        $kaset_tahun = $_POST['kaset_tahun'];
        $kaset_kualitas = $_POST['kaset_kualitas'];
        $kaset_persediaan = $_POST['kaset_persediaan'];
        $kaset_harga = $_POST['kaset_harga'];

        $sql = "INSERT INTO kaset (kaset_nama, kaset_sipnosis, kaset_tahun, kaset_kualitas, kaset_persediaan, kaset_harga, kaset_gambar) VALUES ('$kaset_nama','$kaset_sipnosis','$kaset_tahun','$kaset_tahun','$kaset_persediaan','$kaset_harga','$target_file' )";
        $hasil= $koneksi->query($sql);
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
 }

}

// berfungsi untuk membatasi text di sipnosis
function limit_sipnosis($koneksi) {
//syarat-> harus declare kaset_sipnosis kaset_id di page yg menggunakan fungsi ini 
$jml_text = str_word_count($row['kaset_sipnosis']); 

echo '<p>'.substr($row['kaset_sipnosis'], 0,100).'... <a href="kaset-profile.php?kaset_id='.$row['kaset_id'].'">read more</a></p>';
}
