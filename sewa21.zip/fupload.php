<?php
include 'koneksi.php';
include 'fungsi.php';
include 'index.php';
?>
<script src="tinymce/tinymce.min.js"></script>
<script src="tinymce/jquery.tinymce.min.js"></script>
<script>tinymce.init({ selector:'textarea' });</script>
<form action="for-upload.php" method="post" enctype="multipart/form-data">
<table>
<tbody>
	<tr>
		<td>kaset</td>
		<td><input type="text" name="kaset_nama"></td>
	</tr>
	<tr>
		<td>sipnosis</td>
		<td><textarea name="kaset_sipnosis"></textarea></td>
	</tr>
	<tr>
		<td>tahun</td>
		<td><input type="number" name="kaset_tahun" ></td>
	</tr>
	<tr>
		<td>kualitas</td>
		<td><input type="text" name="kaset_kualitas"></td>
	</tr>
	<tr>
		<td>persedian</td>
		<td><input type="number" name="kaset_persediaan"></td>
	</tr>
	<tr>
		<td>harga</td>
		<td><input type="number" name="kaset_harga" value="1000"></td>
	</tr>
	<tr>
    	<td>Select image to upload:</td>
    	<td><input type="file" name="fileToUpload" id="fileToUpload"></td>
    <tr>
    <tr>
    	<td><br></td>
    	<td><input type="submit" value="Upload Image" name="daftar_kaset"></td>
    <tr>
</form>

</body>
</html>