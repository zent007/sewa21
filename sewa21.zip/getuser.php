<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html>
<head>
<style>
	#txtHint {
		font-size: 7px;
		position: fixed;
		background: #ccc;
		border-radius: 5px;
		width: 380px;
	}

</style>
</head>
<body>

<table>
<tbody>
<?php
$q = intval($_GET['q']);
$sql="SELECT * FROM kaset WHERE kaset_id ='$q'";
$hasil = $koneksi->query($sql);
while ($row = $hasil->fetch_assoc()) {

		echo '<tr>
				<td rowspan="6">
				<img src="'.$row["kaset_gambar"].'" width="80" height="110">
				</td>
				<td>kode</td>
				<td>'.$row["kaset_id"].'</td>
			  </tr>
			  <tr>
			  	<td>judul</td>
				<td>'.$row["kaset_nama"].'</td>
			  </tr>
			  <tr>
			  	<td>tahun</td>
				<td>'.$row["kaset_tahun"].'</td>
			  </tr>
			  <tr>
			  	<td>kualitas</td>
				<td>'.$row["kaset_kualitas"].'</td>
			  </tr>
			  <tr>
			  	<td>persedian</td>
				<td>'.$row["kaset_persediaan"].'</td>
			  </tr>
			  <tr>
			  	<td>harga</td>
				<td>'.$row["kaset_harga"].'</td>
			  </tr>';

	}
	
?>
</tbody>
</table>
</body>
</html>