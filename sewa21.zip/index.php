<html> 
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- offline bootstrap -->
<!--<link rel="stylesheet" type="text/css" href="style.css"> -->
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css"> 
<script src="ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script> 
<!-- offline bootstrap -->

<!-- online bootstrap
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<script src="ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
online bootstrap -->
	<title>Penyewaan Kaset SEWA21</title>
</head>

<div class="container">
<div class="jumbotron">
<header align="center">
	<h1><a href="sewa21.php"><span class="glyphicon-ok"></span>SEWA21</a></h1>	
	<h2>Penyewaan Kaset</h2>
	<a href="transaksi.php">sewa</a> || 
	<a href="laporan-transaksi.php">laporan</a> || 
	<a href="kaset.php">kaset</a> ||
	<a href="member.php">member</a> ||
	<a href="about.php">about</a> <br><br>
	<form method="POST" action="search.php">
	<input type="search" name="cari" align="center" style="width: 300px; padding: 5px 5px 9px 5px ; border: 1px solid #bbb; border-radius: 6px; ">
	<button class="btn btn-primary" name="mencari">Search</button>
	</form>
</header>
</div>