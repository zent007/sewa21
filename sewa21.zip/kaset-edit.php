<?php
include 'koneksi.php';
include 'fungsi.php';
include 'index.php';
?>

<h1 align="center">DATA KASET</h1>
	<div align="center">
		<a href="kaset.php">data kaset</a> ||
		<a href="kaset-register.php">input kaset</a> ||
		<a href="kaset-edit.php">edit kaset</a>
	</div>
<table class="table table-hover table-bordered">
<thead>
	<th width="3">no</th>
	<th>kode</th>
	<th width="200">kaset</th>
	<th>sipnosis</th>
	<th>persedian</th>
	<th>harga</th>
	<th width="130">opsi</th>
</thead>
<tbody>
	<?php 
	$no =1;
	$sql = "SELECT * FROM kaset";
	$hasil = $koneksi->query($sql);
	while ($row = $hasil->fetch_assoc()) {
		echo '<tr>
				<td>'.$no++.'</td>
				<td>'.$row["kaset_id"].'</td>
				<td>'.$row["kaset_nama"].'</td>
				<td>'.$row["kaset_sipnosis"].'</td>
				<td align="center">'.$row["kaset_persediaan"].'</td>
				<td>'.$row["kaset_harga"].'</td>
				<td><div style="dislpay : inline-block;">
					<form method ="POST" action="kaset-medit.php" style="display: inline-block;">
						<input type="hidden" name="kaset_id" value="'.$row['kaset_id'].'">
						<input type="hidden" name="kaset_nama" value="'.$row['kaset_nama'].'">
						<input type="hidden" name="kaset_sipnosis" value="'.$row['kaset_sipnosis'].'">
						<input type="hidden" name="kaset_tahun" value="'.$row['kaset_tahun'].'">
						<input type="hidden" name="kaset_kualitas" value="'.$row['kaset_kualitas'].'">
						<input type="hidden" name="kaset_persediaan" value="'.$row['kaset_persediaan'].'">
						<input type="hidden" name="kaset_harga" value="'.$row['kaset_harga'].'">
						<button class="btn btn-warning btn-sm">edit</button>
					</form>
					<form method="POST" action="'.kaset_hapus($koneksi).'" style="display: inline-block;">
						<input type="hidden" name="kaset_id" value="'.$row['kaset_id'].'">
						<button class="btn btn-danger btn-sm" name="hapus_kaset" >hapus</button>
					</form>
					</div>
				</td>
			  </tr>';

	}
	?>
	
</tbody>
</table>
<?php include 'footer.php'; ?>

