<?php
include 'koneksi.php';
include 'fungsi.php';
include 'index.php';


	$kaset_id = $_POST['kaset_id'];
	$kaset_nama = $_POST['kaset_nama'];
	$kaset_sipnosis = $_POST['kaset_sipnosis'];
	$kaset_persediaan = $_POST['kaset_persediaan'];
	$kaset_harga = $_POST['kaset_harga'];

?>
<div align="center">
<h1>INPUT DATA KASET</h1>
	<div align="center">
		<a href="kaset.php">data kaset</a> ||
		<a href="kaset-register.php">input kaset</a> ||
		<a href="kaset-edit.php">edit kaset</a>
	</div>
<form method="post" action="new-kaset-medit.php" enctype="multipart/form-data">
	<table>
	<tbody>
		<tr>
			<td>kode</td>
				<input type="hidden" name="kaset_id" value="<?php echo $kaset_id; ?>">
				<!--input hidden kaset_id untuk menentukan WHERE yang di UPDATE -->
			<td><input type="text" name="new_kaset_id" value="<?php echo $kaset_id; ?>"></td>
				<!--new_kaset_id untuk edit kaset_id -->
		</tr>
		<tr>
			<td>kaset</td>
			<td><input type="text" name="kaset_nama" value="<?php echo $kaset_nama; ?>"></td>
		</tr>
		<tr>
			<td>sipnosis</td>
			<td><textarea name="kaset_sipnosis"><?php echo $kaset_sipnosis; ?></textarea></td>
		</tr>
		<tr>
			<td>Tahun rilis</td>
			<td><input type="number" name="kaset_tahun" min="1900" max="2050"></td>
		</tr>
		<tr>
			<td>Kualitas Video</td>
			<td>
				<select name="kaset_kualitas">
					<option>4K</option>
					<option>FullHD</option>
					<option>HD</option>
					<option>miniHD</option>
				</select>
		</tr>
		<tr>
			<td>kaset persedian</td>
			<td><input type="number" name="kaset_persediaan" data-toggle="tooltip" data-placement="right" title="masukkan angka!" value="<?php echo $kaset_persediaan; ?>"></td>
		</tr>
		<tr>
			<td>harga</td>
			<td><input type="number" name="kaset_harga" value="<?php echo $kaset_harga; ?>"></td>
		<tr>
	    	<td>Select image to upload:</td>
	    	<td><input type="file" name="fileToUpload" id="fileToUpload"></td>
    	</tr>
    	<tr>
	    	<td><br></td>
	    	<td><input type="submit" value="Upload Image" name="daftar_kaset"></td>
    	<tr>
	</tbody>
	</table>
</form>
</div>

<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});
</script>

<?php include 'footer.php'; ?>
