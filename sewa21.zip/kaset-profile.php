<?php
include 'koneksi.php';
include 'fungsi.php';
include 'index.php';
?>

<h1 align="center">DATA KASET</h1>
	<div align="center">
		<a href="kaset.php">data kaset</a> ||
		<a href="kaset-register.php">input kaset</a> ||
		<a href="kaset-edit.php">edit kaset</a>
	</div>
<table class="table table-bordered">
<tbody>
	<?php 
	if (isset($_GET['kaset_id'])) {
		$kaset_id = $_GET['kaset_id'];
		
	$sql = "SELECT * FROM kaset WHERE kaset_id='$kaset_id'";
	$hasil = $koneksi->query($sql);
	while ($row = $hasil->fetch_assoc()) {
		echo '<tr>
				<td width="160" rowspan="6">
				<img src="'.$row["kaset_gambar"].'" width="160" height="220">
				</td>
				<td>kode</td>
				<td width="200">'.$row["kaset_id"].'</td>
				<td>sipnosis</td>
			  </tr>
			  <tr>
			  	<td>judul</td>
				<td>'.$row["kaset_nama"].'</td>
				<td rowspan="5">'.$row["kaset_sipnosis"].'</td>
			  </tr>
			  <tr>
			  	<td>tahun</td>
				<td>'.$row["kaset_tahun"].'</td>
			  </tr>
			  <tr>
			  	<td>kualitas</td>
				<td>'.$row["kaset_kualitas"].'</td>
			  </tr>
			  <tr>
			  	<td>persedian</td>
				<td>'.$row["kaset_persediaan"].'</td>
			  </tr>
			  <tr>
			  	<td>harga</td>
				<td>'.$row["kaset_harga"].'</td>
			  </tr>
			  	<tr><td><br></td>
			  	<td colspan="3"><a class="btn btn-success" href="transaksi.php?kaset_id='.$row["kaset_id"].'">sewa</a></td>
			  </tr>
			  <tr>
			  	
			  </tr>
			  ';

		} 
	} else {
		header("Location: kaset.php");
	}
	?>
</tbody>
</table>
<?php include 'footer.php'; ?>