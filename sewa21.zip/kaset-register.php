<?php
include 'koneksi.php';
include 'fungsi.php';
include 'index.php';
?>
<script src="tinymce/tinymce.min.js"></script>
<script src="tinymce/jquery.tinymce.min.js"></script>
<script>tinymce.init({ selector:'textarea' });</script>
<div align="center">
<h1>INPUT DATA KASET</h1>
<h3>alternative link <a href="fupload.php">here</a></h3>
	<div align="center">
		<a href="kaset.php">data kaset</a> ||
		<a href="kaset-register.php">input kaset</a> ||
		<a href="kaset-edit.php">edit kaset</a>
	</div>
<form method="POST" action="for-upload.php">
	<table>
	<tbody>
		<tr>
			<td>kaset</td>
			<td><input type="text" name="kaset_nama"></td>
		</tr>
		<tr>
			<td>sipnosis</td>
			<td><textarea name="kaset_sipnosis"></textarea></td>
		</tr>
		<tr>
			<td>Tahun rilis</td>
			<td><input type="number" name="kaset_tahun" min="1900" max="2050"></td>
		</tr>
		<tr>
			<td>Kualitas Video</td>
			<td>
				<select name="kaset_kualitas">
					<option>4K</option>
					<option>FullHD</option>
					<option>HD</option>
					<option>miniHD</option>
				</select>
		</tr>
		<tr>
			<td>kaset persedian</td>
			<td><input type="number" name="kaset_persediaan" data-toggle="tooltip" data-placement="right" title="masukkan angka!"></td>
		</tr>
		<tr>
			<td>harga</td>
			<td><input type="number" name="kaset_harga"></td>
		</tr>
		<tr>
			<td>cover kaset</td>
			<td><input type="file" name="kaset_gambar"></td>
		</tr>
		<td><br></td>
		<tr>
			<td colspan="2" align="center"><button class="btn" name="daftar_kaset" onclick="alert('Apakah anda yakin ?')">DAFTAR</button><td>
		</tr>
	</tbody>
	</table>
</form>
</div>

<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});
</script>

<?php include 'footer.php'; ?>
