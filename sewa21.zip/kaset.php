<?php
include 'koneksi.php';
include 'fungsi.php';
include 'index.php';
?>

<h1 align="center">DATA KASET</h1>
	<div align="center">
		<a href="kaset.php">data kaset</a> ||
		<a href="kaset-register.php">input kaset</a> ||
		<a href="kaset-edit.php">edit kaset</a>
	</div>
<h2>order by <a href="kaset.php?date">DATE</a> || <a href="kaset.php?terlaris">TERLARIS</a> </h2>

	<?php 

	if (isset($_GET['terlaris'])) {
	 // sql for 4 kaset_gambar terpopuler
echo '
		<table class="table table-hover table-bordered">
			<thead>
				<th width="3">no</th>
				<th>kode</th>
				<th width="200">kaset</th>
				<th>persedian</th>
				<th>harga</th>
				<th>terbeli</th>
			</thead>
';
	$no = 1;
	$sql = "SELECT kaset.* , COUNT(transaksi.kaset_id) AS num_kaset from transaksi RIGHT JOIN kaset ON transaksi.kaset_id=kaset.kaset_id GROUP BY transaksi.kaset_id ORDER BY num_kaset DESC";
	$hasil = $koneksi->query($sql);
		while ($row = $hasil->fetch_assoc()) {
		echo '
			<tbody>
			<tr>
				<td>'.$no++.'</td>
				<td>'.$row["kaset_id"].'</td>
				<td>
					<form action="kaset-profile.php" method="GET">
					<input type="hidden" name="kaset_id" value="'.$row["kaset_id"].'"">
					<button style="background: transparent; border: none; color:007ce3;">'.$row["kaset_nama"].'</button>
				</form>
				</td>
				
				<td align="center">'.$row["kaset_persediaan"].'</td>
				<td>'.$row["kaset_harga"].'</td>
				<td>'.$row["num_kaset"].'</td>
			  </tr>';
		}
echo '
			</tbody>
		</table>';
	} else {
echo '
		<table class="table table-hover table-bordered">
			<thead>
				<th width="3">no</th>
				<th>kode</th>
				<th width="200">kaset</th>
				<th>persedian</th>
				<th>harga</th>
			</thead>';
	$no =1;
	$sql = "SELECT * FROM kaset";
	$hasil = $koneksi->query($sql);
	while ($row = $hasil->fetch_assoc()) {
		echo '
				<tr>
					<td>'.$no++.'</td>
					<td>'.$row["kaset_id"].'</td>
					<td>
						<form action="kaset-profile.php" method="GET">
						<input type="hidden" name="kaset_id" value="'.$row["kaset_id"].'"">
						<button style="background: transparent; border: none; color:007ce3;">'.$row["kaset_nama"].'</button>
					</form>
					</td>
					
					<td align="center">'.$row["kaset_persediaan"].'</td>
					<td>'.$row["kaset_harga"].'</td>
				  </tr>';
			}
echo '
</tbody>
		</table>';
	}
	?>

<?php include 'footer.php'; ?>