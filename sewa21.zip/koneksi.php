<?php

$koneksi = mysqli_connect("localhost","root","","sewa21");

	if (!$koneksi) {
		die("koneksi gagal: ".mysqli_connect_error());
	}