<?php
include 'koneksi.php';
include 'fungsi.php';
include 'index.php';
?>

    <!-- Morris Charts CSS -->
    <link href="vendor/morrisjs/morris.css" rel="stylesheet">

<div align="center">
	<h1>LAPORAN TRANSAKSI</h1>
	<a href="laporan-transaksi.php">Laporan Tabel</a> ||
	<a href="laporan-trans-grafik.php">Laporan Grafik</a>
</div>
    <div id="wrapper">
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Laporan Transaksi Per Hari</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                
                
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Bar Chart Example
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div id="morris-bar-chart"></div>
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
                
                
                <!-- /.col-lg-6 -->
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Penggunaan Morris.js 
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <p>Morris.js is a jQuery based charting plugin created by Olly Smith. In SB Admin, we are using the most recent version of Morris.js which includes the resize function, which makes the charts fully responsive. The documentation for Morris.js is available on their website, <a target="_blank" href="http://morrisjs.github.io/morris.js/">http://morrisjs.github.io/morris.js/</a>.</p>
                            <a target="_blank" class="btn btn-default btn-lg btn-block" href="http://morrisjs.github.io/morris.js/">View Morris.js Documentation</a>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<?php
$sql = "SELECT transaksi.transaksi_tgl_sewa, SUM(kaset.kaset_harga) FROM kaset RIGHT JOIN transaksi ON kaset.kaset_id=transaksi.kaset_id GROUP BY CAST(transaksi_tgl_sewa AS DATE)";
	$hasil = $koneksi->query($sql);
	while ($row = $hasil->fetch_assoc()) {
		$output[] =$row;
	}
?>

    <!-- Morris Charts JavaScript -->
    <script src="vendor/raphael/raphael.min.js"></script>
    <script src="vendor/morrisjs/morris.min.js"></script>

    <!-- Morris js = data dari DB di JSON -->
    <script type="text/javascript">
    	$(function() {

    Morris.Line({
        element: 'morris-bar-chart',
        data:<?php echo json_encode($output); ?> ,
        xkey: 'transaksi_tgl_sewa',
        ykeys: ['SUM(kaset.kaset_harga)'],
        labels: ['Total Sewa'],
        hideHover: 'auto',
        resize: true
    });
    
});

    </script>

<?php include 'footer.php'; ?>