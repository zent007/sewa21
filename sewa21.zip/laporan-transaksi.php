<?php
include 'koneksi.php';
include 'fungsi.php';
include 'index.php';
?>
<div align="center">
	<h1>LAPORAN TRANSAKSI</h1>
	<a href="laporan-transaksi.php">Laporan Tabel</a> ||
	<a href="laporan-trans-grafik.php">Laporan Grafik</a>
</div>
<table class="table table-hover table-bordered">
<thead>
	<th>no</th>
	<th>kode transaksi</th>
	<th>kode kaset</th>
	<th>kaset</th>
	<th>tgl sewa</th>
	<th>tgl kembali</th>
	<th>harga</th>
</thead>
<tbody>
	<?php listALL($koneksi); ?>
</tbody>
</table>
<?php include 'footer.php'; ?>