<?php
include 'koneksi.php';
include 'fungsi.php';
include 'index.php';
?>
<div align="center">
	<h1 align="center">EDIT DATA MEMBER</h1>
	<div>
		<a href="member-reg.php">member baru</a> ||
		<a href="member.php">data member</a> ||
		<a href="member-edit.php">edit member</a>
	</div>
	<table class="table table-hover table-bordered">
	<thead>
		<th width="3">no</th>
		<th>kode</th>
		<th>nama</th>
		<th>alamat</th>
		<th width="120">opsi</th>
	</thead>
	<tbody>
		<?php 
		$no =1;
		$sql = "SELECT * FROM member";
		$hasil = $koneksi->query($sql);
		while ($row = $hasil->fetch_assoc()) {
			echo '<tr>
					<td>'.$no++.'</td>
					<td>'.$row["member_id"].'</td>
					<td>'.$row["member_nama"].'</td>
					<td>'.$row["member_alamat"].'</td>
					<td><div style="dislpay : inline-block;">
						<form method ="POST" action="member-medit.php" style="display: inline-block;">
							<input type="hidden" name="member_id" value="'.$row['member_id'].'">
							<input type="hidden" name="member_nama" value="'.$row['member_nama'].'">
							<input type="hidden" name="member_alamat" value="'.$row['member_alamat'].'">
							<button class="btn btn-warning btn-sm">edit</button>
						</form>
						<form method="POST" action="'.member_hapus($koneksi).'" style="display: inline-block;">
							<input type="hidden" name="member_id" value="'.$row['member_id'].'">
							<button class="btn btn-danger btn-sm" name="hapus_member" >hapus</button>
						</form>
						</div>
					</td>
				  </tr>';

		}
		?>
		
	</tbody>
	</table>
</div>
<?php include 'footer.php'; ?>

