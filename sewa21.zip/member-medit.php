<?php
include 'koneksi.php';
include 'fungsi.php';
include 'index.php';


	$member_id = $_POST['member_id'];
	$member_nama = $_POST['member_nama'];
	$member_alamat = $_POST['member_alamat'];

?>
<div align="center">
<h1>EDIT DATA MEMBER</h1>
	<div>
		<a href="member-reg.php">member baru</a> ||
		<a href="member.php">data member</a> ||
		<a href="member-edit.php">edit member</a>
	</div>
<form method="POST" action="<?php member_medit($koneksi) ?>">
	<table>
	<tbody>
		<tr>
			<td>ID MEMBER</td>
				<input type="hidden" name="member_id" value="<?php echo $member_id; ?>">
				<!--input hidden member_id untuk menentukan WHERE yang di UPDATE -->
			<td><input type="text" name="new_member_id" value="<?php echo $member_id; ?>"></td>
				<!--new_member_id untuk edit member_id -->
		</tr>
		<tr>
			<td>NAMA</td>
			<td><input type="text" name="member_nama" value="<?php echo $member_nama; ?>"></td>
		</tr>
		<tr>
			<td>ALAMAT</td>
			<td><input type="text" name="member_alamat" value="<?php echo $member_alamat; ?>"></td>
		</tr>
		<td><br></td>
		<tr>
			<td colspan="2" align="center"><button class="btn" name="medit_member">EDIT</button><td>
		</tr>
	</tbody>
	</table>
</form>
</div>

<?php include 'footer.php'; ?>
