<?php
include 'koneksi.php';
include 'fungsi.php';
include 'index.php';
?>
<div align="center">
	<h1>INPUT DATA MEMBER</h1>
	<div>
		<a href="member-reg.php">member baru</a> ||
		<a href="member.php">data member</a> ||
		<a href="member-edit.php">edit member</a>
	</div>
	<form method="POST" action="member-upload.php" enctype="multipart/form-data">
		<table>
		<tbody>
			<tr>
				<td>nama</td>
				<td><input type="text" name="member_nama"></td>
			</tr>
			<tr>
				<td>alamat</td>
				<td><input type="text" name="member_alamat"></td>
			</tr>
			<tr>
				<td>foto profile</td>
				<td><input type="file" name="fileToUpload" id="fileToUpload"></td>
			</tr>
			<td><br></td>
			<tr>
				<td colspan="2" align="center"><input type="submit" value="Upload Image" name="daftar_member"></td>
			</tr>
		</tbody>
		</table>
	</form>
</div>

<?php include 'footer.php'; ?>
