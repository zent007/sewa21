<?php
include 'koneksi.php';
include 'fungsi.php';
include 'index.php';
?>

<div align="center">
	<h1>DATA MEMBER</h1>
	<div>
		<a href="member-reg.php">member baru</a> ||
		<a href="member.php">data member</a> ||
		<a href="member-edit.php">edit member</a>
	</div>
	<table class="table table-hover table-bordered">
		<thead>
			<th width="3">no</th>
			<th width="150">kode member</th>
			<th>nama</th>
			<th>alamat</th>
		</thead>
		<tbody>
			<?php member($koneksi); ?>
		</tbody>
	</table>
</div>
<?php include 'footer.php'; ?>