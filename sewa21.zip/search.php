<?php
include 'koneksi.php';
include 'fungsi.php';
include 'index.php';
?>

<style type="text/css">

	.king {
		float: left;
		align-content: center;
	}

	.pic4{
		position: relative;
		width: 170px;
		height: 250px;
		float: left;
		z-index: 1;
		transition-duration: 0.7s;
	
	}
	.pic4:hover {
		opacity: 0.3;
		z-index: 0;
	}
	.pic-wrap {
		position: relative;
		float: left;
	}
	.pic-center button {
		padding: 0px;
		position: absolute;
		top : 100px;
		left: 65px;
		z-index: 0;
	}
	.pic-center p{
	

		color: #777;
		background: #ccc;
		padding: 3px;
		border-radius: 5px;
	}
	.pic-center button:hover {
		z-index: 1;
	}
	.aktif-jon {
		display: block;
	}
	.flex-container {
    display: -webkit-flex;
    display: flex;
    -webkit-justify-content: center;
    justify-content: center;
    height: auto;
    background-color: lightgrey;
	}

	.flex-item {
		float: left;
	    margin: 10px;
	}
</style>

<div>
<h1 align="center">PENCARIAN</h1>
<?php 
if (isset($_POST['mencari'])){
$cari = $_POST['cari'];

echo '<h1 align="center">'.$cari.'</h1>';
	$sql = "SELECT * FROM kaset  WHERE kaset_nama LIKE '%$cari%' OR kaset_id LIKE '%$cari%'";
	$hasil = $koneksi->query($sql);
	while ($row = $hasil->fetch_assoc()) {

?>
	<table class="table table-bordered ">

		<tbody>
			<tr>							
				<td width="160" rowspan="6">
				<?php echo '<img src="'.$row["kaset_gambar"].'" width="160" height="220"'; ?>
				</td>
				<td width="150">judul</td>
				<td><?php echo $row["kaset_nama"]; ?></td>
			</tr>
			<tr>
				<td>sipnosis</td>
				<td><?php echo $row["kaset_sipnosis"]; ?></td>
			</tr>
			<tr>
				<td>tahun</td>
				<td><?php echo $row["kaset_tahun"]; ?></td>
			</tr>
			<tr>
				<td>kualitas</td>
				<td><?php echo $row["kaset_kualitas"]; ?></td>
			</tr>
			<tr>
				<td>harga</td>
				<td><?php echo $row["kaset_harga"]; ?></td>
			</tr>
			<tr>
				<td colspan="3"><button class="btn btn-success" style="padding: 5px 30px 5px 30px;">SEWA</button></td>
			</tr>
		</tbody>
	</table>
<?php
	
} // close for while 

} // close for isset [mencari]

?>
</div>

</script>

<?php include 'footer.php'; ?>