<?php
include 'koneksi.php';
include 'fungsi.php';
include 'index.php';
?>

<style type="text/css">

	.king {
		float: left;
		align-content: center;
	}

	.pic4{
		position: relative;
		width: 170px;
		height: 250px;
		float: left;
		z-index: 1;
		transition-duration: 0.7s;
	
	}
	.pic4:hover {
		opacity: 0.8;
		-webkit-filter: brightness(10%);filter: brightness(10%);
		z-index: 0;
	}
	.pic-wrap {
		position: relative;
		float: left;
	}
	.pic-center button {
		padding: 0px;
		position: absolute;
		top : 100px;
		left: 30px;
		z-index: 0;
	}
	.pic-center p{
		color: #777;
		background: #ccc;
		padding: 3px;
		border-radius: 5px;
	}
	.pic-center button:hover {
		z-index: 1;
	}
	.aktif-jon {
		display: block;
	}
	.flex-container {
    display: -webkit-flex;
    display: flex;
    -webkit-justify-content: center;
    justify-content: center;
    height: auto;
    background-color: lightgrey;
	}

	.flex-item {
		float: left;
	    margin: 10px;
	}

	.pic-center button.btn-sewa {
		padding: 5px 30px 5px;
		border: none;
		font-size: 22px;
	}
</style>
<h1 align="center">KASET TERPOPULER</h1>
<div class="flex-container">

<?php // sql for 4 kaset_gambar terpopuler
$sql = "SELECT kaset.kaset_id, kaset.kaset_gambar , COUNT(transaksi.kaset_id) AS num_kaset from transaksi RIGHT JOIN kaset ON transaksi.kaset_id=kaset.kaset_id GROUP BY transaksi.kaset_id ORDER BY num_kaset DESC LIMIT 4";
$hasil = $koneksi->query($sql);
while ($row = $hasil->fetch_assoc()) {
echo ' 

  <div class="flex-item pic-wrap">
  	<a href="kaset-profile.php?kaset_id='.$row['kaset_id'].'"><img class="pic4" src="'.$row['kaset_gambar'].'"></a>
	<div class="pic-center">
		<button class="btn-sewa">sewa</button>
		
	</div>
  </div>';
}
?>

</div>
<br><br>
<div>
<h1 align="center">KASET TERBARU</h1>

<?php 

//menghitung total kaset
$sql = "SELECT COUNT(*) FROM kaset";
$hasil = $koneksi->query($sql);
while ($row = $hasil->fetch_assoc()) {
$jml_kaset = $row['COUNT(*)'];
}
//jumlah kaset dari tabel kaset = $jml_kaset

$limit_page = 5;
//per halaman akan ditampilkan 5 kaset
$jumlah_page = ceil($jml_kaset/$limit_page);
//ceil untuk membulatkan hasil aritmatik
//$num_hlm =jumlah hlm yang akan ditampilkan

if (isset($_GET['page'])) {
	$page=$_GET['page'];
	$start=$limit_page*($page-1);
} else {
	$page=1;
	$start=0;
}
/*
script asli dibawah, yg ^^ modifikasi
$page=$_GET['page'];
if (empty($page)){
	$page=1;
	$start=0;
}else{
	$start=$limit_page*($page-1);
}*/

// sql for pagination terbaru
$sql = "SELECT * FROM kaset ORDER BY kaset_log_date DESC LIMIT $start , $limit_page ";
$hasil = $koneksi->query($sql);
while ($row = $hasil->fetch_assoc()) {

?>
	<table class="table table-bordered ">

		<tbody>
			<tr>							
				<td width="160" rowspan="6">
				<?php echo '<a href="kaset-profile.php?kaset_id='.$row['kaset_id'].'"><img src="'.$row["kaset_gambar"].'" width="160" height="220"></a>'; ?>
				</td>
				<td width="150">judul</td>
				<td><?php echo '<a href="kaset-profile.php?kaset_id='.$row['kaset_id'].'">'.$row["kaset_nama"].'</a>'; ?></td>
			</tr>
			<tr>
				<td>sipnosis</td>
				<td>
				<?php 
					$jml_text = str_word_count($row['kaset_sipnosis']); 
echo substr($row['kaset_sipnosis'], 0,220).'... <a href="kaset-profile.php?kaset_id='.$row['kaset_id'].'">read more>></a></p>';
				 ?>	
				 </td>
			</tr>
			<tr>
				<td>tahun</td>
				<td><?php echo $row["kaset_tahun"]; ?></td>
			</tr>
			<tr>
				<td>kualitas</td>
				<td><?php echo $row["kaset_kualitas"]; ?></td>
			</tr>
			<tr>
				<td>harga</td>
				<td><?php echo $row["kaset_harga"]; ?></td>
			</tr>
			<tr>
				<td colspan="3"><a class="btn btn-success" href="<?php echo 'transaksi.php?kaset_id='.$row["kaset_id"];?>">sewa</a></td>
			</tr>
		</tbody>
	</table>
<?php
	
}// close bracket while => SELECT * FROM kaset ORDER BY kaset_log_date

?>

<?php

$a = 1;
while ( $a <= $jumlah_page) {
echo '<ul class="pagination">';
echo    '<li><a href="?page='.$a.'">'.$a++.'</a></li>';
echo '</ul>';	
}
?>

</div>

</script>

<?php include 'footer.php'; ?>