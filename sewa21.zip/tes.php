<?php
include 'koneksi.php';
include 'fungsi.php';
include 'index.php';
?>
<form id="form1" name="isian" method="POST" action="tes1.php" enctype="multipart/form-data">
    <input type="text" name="kaset_nama">
    <tr>
      <td>Foto:</td>
      <td><input type="file" name="image" id="file" /> </td>
    </tr>
<input type="submit" name="button" id="button" value="Simpan data" />
</form>
</body>
</html>

