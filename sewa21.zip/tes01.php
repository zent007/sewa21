<?php
include 'koneksi.php';

$sql = "SELECT COUNT(*) FROM kaset";
$hasil = $koneksi->query($sql);
while ($row = $hasil->fetch_assoc()) {
$jml_kaset = $row['COUNT(*)'];
}
echo "jumlah kaset ".$jml_kaset;
echo 'per halaman akan ditampilkan 5 kaset<br>';
$per_hlm = 5;
$num_hlm = ceil($jml_kaset/$per_hlm);

echo 'total hlm keseluruhan '.$num_hlm;
$a = 1;
while ( $a <= $num_hlm) {
echo '<ul>';
echo    '<li><a href="?page='.$a.'">'.$a++.'</a></li>';
echo '</ul>';	
}/*
echo '<ul>';
echo    '<li><a href="?page=1">1</a></li>';
echo '</ul>';*/