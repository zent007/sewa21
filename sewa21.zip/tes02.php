<?php
include 'koneksi.php';
include 'fungsi.php';
?>

<html> 
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" type="text/css" href="style.css">
<!-- offline bootstrap -->
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css"> 
<script src="ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script> 
<!-- offline bootstrap -->

<!-- online bootstrap
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<script src="ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
online bootstrap -->
	<title>Penyewaan Kaset SEWA21</title>
</head>

<div class="container">
<div class="jumbotron">
<header align="center">
	<h1><a href="sewa21.php"><span class="glyphicon-ok"></span>SEWA21</a></h1>	
	<h2>Penyewaan Kaset</h2>
	<a href="transaksi.php">sewa</a> || 
	<a href="laporan-transaksi.php">laporan</a> || 
	<a href="kaset.php">kaset</a> ||
	<a href="member.php">member</a> ||
	<a href="about.php">about</a> <br><br>
	<form method="POST" action="search.php">
	<input type="search" name="cari" align="center" style="width: 300px; padding: 5px 5px 9px 5px ; border: 1px solid #bbb; border-radius: 6px; ">
	<button class="btn btn-primary" name="mencari">Search</button>
	</form>
</header>
</div>

<h1 id="hah" align="center">KASET TERPOPULER</h1>
<div class="flex-container">

<?php // sql for 4 kaset_gambar terpopuler
$sql = "SELECT kaset.kaset_id, kaset.kaset_gambar , COUNT(transaksi.kaset_id) AS num_kaset from transaksi RIGHT JOIN kaset ON transaksi.kaset_id=kaset.kaset_id GROUP BY transaksi.kaset_id ORDER BY num_kaset DESC LIMIT 4";
$hasil = $koneksi->query($sql);
while ($row = $hasil->fetch_assoc()) {
echo ' 

  <div class="flex-item pic-wrap">
  <p class="sewa">sewa</p>
  	<a class="sd" href="kaset-profile.php?kaset_id='.$row['kaset_id'].'"><img class="pic4" src="'.$row['kaset_gambar'].'"></a>
	
  </div>';
}
?>

</div>
<br><br>
<div class="wrapPage">
<h1 align="center">KASET TERBARU</h1>

<?php 

//menghitung total kaset
$sql = "SELECT COUNT(*) FROM kaset";
$hasil = $koneksi->query($sql);
while ($row = $hasil->fetch_assoc()) {
$jml_kaset = $row['COUNT(*)'];
}
//jumlah kaset dari tabel kaset = $jml_kaset

$limit_page = 5;
//per halaman akan ditampilkan 5 kaset
$jumlah_page = ceil($jml_kaset/$limit_page);
//ceil untuk membulatkan hasil aritmatik
//$num_hlm =jumlah hlm yang akan ditampilkan

if (isset($_GET['page'])) {
	$page=$_GET['page'];
	$start=$limit_page*($page-1);
} else {
	$page=1;
	$start=0;
}
/*
script asli dibawah, yg ^^ modifikasi
$page=$_GET['page'];
if (empty($page)){
	$page=1;
	$start=0;
}else{
	$start=$limit_page*($page-1);
}*/


// sql for pagination terbaru
$sql = "SELECT * FROM kaset ORDER BY kaset_log_date DESC LIMIT $start , $limit_page ";
$hasil = $koneksi->query($sql);
while ($row = $hasil->fetch_assoc()) {

?>
<div class="panel panel-default isi">
<div class="panel panel-heading">
	<?php echo '<a href="kaset-profile.php?kaset_id='.$row['kaset_id'].'">'.$row["kaset_nama"].'</a>'; ?>
</div>
<div class="panel-body">
<div class="imgHome">
	<?php echo '<a href="kaset-profile.php?kaset_id='.$row['kaset_id'].'"><img src="'.$row["kaset_gambar"].'" width="160" height="220"></a>'; ?>
</div>
<div class="isiHome">
	<span class="isiColor">judul </span><?php echo '<a href="kaset-profile.php?kaset_id='.$row['kaset_id'].'">'.$row["kaset_nama"].'</a>'; ?><br>
	<span class="isiColor">tahun </span><?php echo $row["kaset_tahun"]; ?><br>
	<span class="isiColor">kualitas </span><?php echo $row["kaset_kualitas"]; ?><br>
	<span class="isiColor">harga </span><?php echo $row["kaset_harga"]; ?><br>
	<span class="isiColor">sipnosis </span>
	<?php 
		$jml_text = str_word_count($row['kaset_sipnosis']); 
		echo substr($row['kaset_sipnosis'], 0,220).'... <a href="kaset-profile.php?kaset_id='.$row['kaset_id'].'">read more>></a></p>';
	?><br>
	<button class="btn btn-success" style="padding: 5px 30px 5px 30px;">SEWA</button>
</div>
<!-- div isiHome -->
</div>
<!-- div isi -->
</div>
<?php
	
}// close bracket while => SELECT * FROM kaset ORDER BY kaset_log_date
?>
</div>
<!-- div wrapPage -->
<?php
$a = 1;
while ( $a <= $jumlah_page) {
echo '<ul class="pagination">';
echo    '<li><a href="?page='.$a.'">'.$a++.'</a></li>';
echo '</ul>';	
}
?>


</script>

<?php include 'footer.php'; ?>