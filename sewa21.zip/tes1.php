<?php
include 'koneksi.php';
include 'fungsi.php';
include 'index.php';
?>

<?php
$sql = "SELECT * FROM kaset WHERE kaset_id='80845'";
$hasil = $koneksi->query($sql);
while ($row = $hasil->fetch_assoc()) {
  $kaset_sipnosis = $row['kaset_sipnosis'];
  $kaset_id = $row['kaset_id'];
}

echo $kaset_sipnosis;
$jml_text = str_word_count($kaset_sipnosis); 

?>
<p><?php echo substr($kaset_sipnosis, 0,100).'... <a href="kaset-profile.php?kaset_id='.$kaset_id.'">read more</a>' ;?></p>
