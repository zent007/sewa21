<?php
include 'koneksi.php';
include 'fungsi.php';
include 'index.php';
//mendeklarasikan variabel untuk input tanggal
$tgl=strtotime("now");
$tglP7=strtotime("+7 day");
?>
<style>
	#txtHint {		
		display: none;
}
	td {
		padding: 2px 4px 2px 10px;
	}
</style>

<script>
function showUser(str) {
    if (str == "") {
        document.getElementById("txtHint").innerHTML = "";
        return;
    } else { 
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("txtHint").innerHTML = xmlhttp.responseText;
                document.getElementById("txtHint").style.display="block";
                document.getElementById("txtHint").style.transition="width 2s";
            }
        };
        xmlhttp.open("GET","getuser.php?q="+str,true);
        xmlhttp.send();
    }
}


</script>
<div id="txtHint"></div>
<div align="center">
<h1>SEWA KASET</h1>
<form method="POST" action="<?php transaksi_daftar($koneksi); ?>">
	<table>
	<tbody>
		<tr>
			<td>kode kaset</td>
			<td><input oninput="showUser(this.value)"  name="kaset_id" list="tes"><datalist id="tes"><?php opsi_kaset($koneksi); ?></datalist></td>
		</tr>
		<tr>

			<td><input type="hidden" value="<?php echo date("Y-m-d", $tgl);  ?> " name="transaksi_tgl_sewa" data-toggle="tooltip" data-placement="right" title='format tgl "yyyy/mm/dd"''></td>
		</tr>
		<tr>

			<td><input type="hidden" value="<?php echo date("Y-m-d", $tglP7); ?>" name="transaksi_tgl_kembali" data-toggle="tooltip" data-placement="right" title='format tgl "yyyy/mm/dd"''></td>
		</tr>
		<tr align="center">
			<td colspan="2" ><button class="btn" name="daftar_transaksi">DAFTAR</button><td>
		</tr>
	</tbody>
	</table>
</form>
</div>

<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});

$(document).ready(function() {
    var max_fields      = 10; //maximum input boxes allowed
    var wrapper         = $(".input_fields_wrap"); //Fields wrapper
    var add_button      = $(".add_field_button"); //Add button ID
    
    var x = 1; //initlal text box count
    $(add_button).click(function(e){ //on add input button click
        e.preventDefault();
        if(x < max_fields){ //max input box allowed
            x++; //text box increment
            $(wrapper).append('<div><input type="text" name="mytext[]"/><a href="#" class="remove_field">Remove</a></div>'); //add input box
        }
    });
    
    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
        e.preventDefault(); $(this).parent('div').remove(); x--;
    })
});
</script>

<?php include 'footer.php'; ?>

