<?php
include 'koneksi.php';

if(isset($_POST["sub"])){
if(isset($_POST["mytext"]) && is_array($_POST["mytext"])){  
    $capture_field_vals ="";
    foreach($_POST["mytext"] as $key => $text_field){
        $capture_field_vals .= $text_field .", ";
    }
    echo $capture_field_vals;
}


$sql = "INSERT INTO member (member_nama) VALUES( $capture_field_vals )";
	$hasil= $koneksi->query($sql);

}
}
?>