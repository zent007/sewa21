<?php
include 'koneksi.php';
include 'fungsi.php';
include 'index.php';
?>

<style type="text/css">

	.king {
		float: left;
		align-content: center;
	}

	.pic4{
		position: relative;
		width: 170px;
		height: 250px;
		float: left;
		z-index: 1;
		transition-duration: 0.7s;
	
	}
	.pic4:hover {
		opacity: 0.3;
		z-index: 0;
	}
	.pic-wrap {
		position: relative;
		float: left;
	}
	.pic-center button {
		padding: 0px;
		position: absolute;
		top : 100px;
		left: 65px;
		z-index: 0;
	}
	.pic-center p{
	

		color: #777;
		background: #ccc;
		padding: 3px;
		border-radius: 5px;
	}
	.pic-center button:hover {
		z-index: 1;
	}
	.aktif-jon {
		display: block;
	}
	.flex-container {
    display: -webkit-flex;
    display: flex;
    -webkit-justify-content: center;
    justify-content: center;
    height: auto;
    background-color: lightgrey;
	}

	.flex-item {
		float: left;
	    margin: 10px;
	}
</style>
<h1 align="center">KASET TERPOPULER</h1>
<div class="flex-container">

<?php // menampilkan 4 kaset_gambar terbaru
$sql = "SELECT kaset.kaset_nama, kaset.kaset_gambar , COUNT(transaksi.kaset_id) AS num_kaset from transaksi RIGHT JOIN kaset ON transaksi.kaset_id=kaset.kaset_id GROUP BY transaksi.kaset_id ORDER BY num_kaset DESC LIMIT 4";
$hasil = $koneksi->query($sql);
while ($row = $hasil->fetch_assoc()) {
echo ' 

  <div class="flex-item pic-wrap">
  	<img class="pic4" src="'.$row['kaset_gambar'].'">
	<div class="pic-center">
		<button class="btn btn-success btn">sewa<p>'.$row['kaset_nama'].'</p></button>
		
	</div>
  </div>';
}
?>

</div>
<br><br>
<div>
<h1 align="center">KASET TERBARU</h1>
<?php 
	$sql = "SELECT * FROM kaset ORDER BY kaset_log_date DESC LIMIT 5 ";
	$hasil = $koneksi->query($sql);
	while ($row = $hasil->fetch_assoc()) {

?>
	<table class="table table-bordered ">

		<tbody>
			<tr>							
				<td width="160" rowspan="6">
				<?php echo '<img src="'.$row["kaset_gambar"].'" width="160" height="220"'; ?>
				</td>
				<td width="150">judul</td>
				<td><?php echo $row["kaset_nama"]; ?></td>
			</tr>
			<tr>
				<td>sipnosis</td>
				<td><?php echo $row["kaset_sipnosis"]; ?></td>
			</tr>
			<tr>
				<td>tahun</td>
				<td><?php echo $row["kaset_tahun"]; ?></td>
			</tr>
			<tr>
				<td>kualitas</td>
				<td><?php echo $row["kaset_kualitas"]; ?></td>
			</tr>
			<tr>
				<td>harga</td>
				<td><?php echo $row["kaset_harga"]; ?></td>
			</tr>
			<tr>
				<td colspan="3"><button class="btn btn-success" style="padding: 5px 30px 5px 30px;">SEWA</button></td>
			</tr>
		</tbody>
	</table>
<?php
	
}

?>


<?php 


?>



<ul class="pagination">
  <li><a href="<?php echo 'page=1"'; ?>">1</a></li>
  <li><a href="?page=2">2</a></li>
  <li><a href="#">3</a></li>
  <li><a href="#">4</a></li>
  <li><a href="#">5</a></li>
</ul>
</div>

</script>

<?php include 'footer.php'; ?>