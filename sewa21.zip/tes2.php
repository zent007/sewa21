<?php
include 'koneksi.php';
$member_nama=$_GET['member_nama'];

$sql="SELECT * FROM member WHERE member_nama='$member_nama'";
$hasil = $koneksi->query($sql);
while ($row = $hasil->fetch_assoc()) {

header("Content-type: image/jpeg");
echo $row["0"];
} 

  
?>